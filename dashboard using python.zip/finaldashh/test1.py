from flask import Flask, redirect, url_for, render_template, request,Markup
from flask_mysqldb import MySQL
import time
import calendar
from datetime import  datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# Initialize the Flask application


app = Flask(__name__)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'datavalues'
app.config['MYSQL_PORT'] = 3307

mysql = MySQL(app)

@app.route('/')
def index():
    return render_template('login.html')


@app.route('/', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['pass'] != 'admin123':
            error = 'Invalid Credentials. Please try again.'
        else:
            return redirect(url_for('success'))
    return render_template('login.html', error=error)


@app.route('/success')
def success():
    return render_template("dashboard.html")

labels1 = ['77Q1MOkM', 'ASYS1mF0', '7Jw2noKv', 'xcvnm','sijv7ocX','77Q1MOkM']
values1=['56.50','18,70','23.40','0','20.60','23.00']
values2=['0','0','0','24.60','0','0']
colors = ["#F7464A", "#46BFBD", "#FDB45C", "#FEDCBA",]

@app.route('/success',methods=['GET','POST'])
def success3():
    if request.method == "POST":
        input_text1 = request.form['t2']
        if input_text1 != None:
            cur = mysql.connection.cursor()
            cur.execute('SELECT temperature FROM datavalues WHERE company_id="' + input_text1 + '" limit 4')
            value= cur.fetchall()
            cur.close()
            if input_text1=='aesdfg':
                bar_labels = labels1
                bar_values = values2
            else:
                bar_labels = labels1
                bar_values = values1

        else:
            return redirect(url_for('success'))
    return render_template('dashboard.html', title='Temperature of devices', max=80, labels=bar_labels, values=bar_values)


@app.route('/checkd')
def succe():
    return render_template("checkdevice.html")


@app.route('/checkd',methods=['GET', 'POST'])
def checkd():
    fetchdata=None
    if request.method == "POST":
        companyid = request.form['coid']
        if companyid != None:
            cur = mysql.connection.cursor()
            cur.execute('SELECT  device_id,temperature,humidity FROM datavalues WHERE company_id ="'+companyid+'"')
            fetchdata = cur.fetchall()
            cur.close()
        else:
            return redirect(url_for('checkd'))
    return render_template('checkdevice.html', data=fetchdata)

@app.route('/cdd')
def cdd1():
    return render_template('devicedetails.html')

@app.route('/cdd', methods=['GET','POST'])
def cdd():
    result=None
    if request.method == "POST":
        input1=request.form['comid']
        input2=request.form['deid']
        if input1 != None or input2 != None:
            cur = mysql.connection.cursor()
            cur.execute('SELECT  company_id,device_id,temperature,humidity FROM datavalues WHERE company_id ="' + input1 + '" and device_id = "'+ input2 +'"')
            result = cur.fetchall()
            cur.close()
        else:
            return redirect(url_for('cdd'))
    return render_template('devicedetails.html',res=result)




@app.route('/checkt')
def succ2():
    return render_template('checkt.html')

@app.route('/checkt',methods=['GET','POST'])
def checkt():
    result1=()
    result2=()
    result3=()
    result4=()
    if request.method == "POST":
        input1 = request.form.get('device1')
        input2 = request.form.get('device2')
        input3 = request.form.get('device3')
        input4 = request.form.get('device4')
        input5 = request.form['fromdate']
        input6 = request.form['todate']
        time_tuple1 = time.strptime(input5, '%Y-%m-%d')
        time_tuple2 = time.strptime(input6, '%Y-%m-%d')
        date1 = calendar.timegm(time_tuple1)
        date2 = calendar.timegm(time_tuple2)
        #if input_text4 != None and input_text5 != None:
        cur = mysql.connection.cursor()
            # sql="select device_id,temperature,humidity from data where id=1"
        if input1!=None:
            cur.execute('SELECT temperature,humidity FROM datavalues WHERE device_id="'+ input1 +'" and temp_date BETWEEN "'+ str(date1) +'" and "'+ str(date2) +'" ')
            result1 = cur.fetchall()
        if input2 != None:
            cur.execute('SELECT temperature,humidity FROM datavalues WHERE device_id="' + input2 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result2 = cur.fetchall()
        if input3 != None:
            cur.execute('SELECT temperature,humidity FROM datavalues WHERE device_id="' + input3 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result3 = cur.fetchall()
        if input4 != None:
            cur.execute('SELECT temperature,humidity FROM datavalues WHERE device_id="' + input4 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result4 = cur.fetchall()
            cur.close()
        #else:
            #return redirect(url_for('checkt'))
    return render_template('report.html', res1=result1, res2=result2, res3=result3, res4=result4)


@app.route('/checkh')
def succ3():
    return render_template('checkh.html')

@app.route('/checkh',methods=['GET','POST'])
def checkh():
    result1 = ()
    result2 = ()
    result3 = ()
    result4 = ()
    result11 = ()
    result21 = ()
    result31 = ()
    result41 = ()
    if request.method == "POST":
        input1 = request.form.get('device1')
        input2 = request.form.get('device2')
        input3 = request.form.get('device3')
        input4 = request.form.get('device4')
        input5 = request.form['fromdate']
        input6 = request.form['todate']
        time_tuple1 = time.strptime(input5, '%Y-%m-%d')
        time_tuple2 = time.strptime(input6, '%Y-%m-%d')
        date1 = calendar.timegm(time_tuple1)
        date2 = calendar.timegm(time_tuple2)
        # if input_text4 != None and input_text5 != None:
        cur = mysql.connection.cursor()
        # sql="select device_id,temperature,humidity from data where id=1"
        if input1 != None:
            cur.execute('SELECT temperature FROM datavalues WHERE device_id="' + input1 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result1 = cur.fetchall()
            cur.execute('SELECT humidity FROM datavalues WHERE device_id="' + input1 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result11 = cur.fetchall()
        if input2 != None:
            cur.execute('SELECT temperature FROM datavalues WHERE device_id="' + input1 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result2 = cur.fetchall()
            cur.execute('SELECT humidity FROM datavalues WHERE device_id="' + input1 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result21 = cur.fetchall()
        if input3 != None:
            cur.execute('SELECT temperature FROM datavalues WHERE device_id="' + input3 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result3 = cur.fetchall()
            cur.execute('SELECT humidity FROM datavalues WHERE device_id="' + input3 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result31 = cur.fetchall()
        if input4 != None:
            cur.execute('SELECT temperature FROM datavalues WHERE device_id="' + input4 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result4 = cur.fetchall()
            cur.execute('SELECT humidity FROM datavalues WHERE device_id="' + input4 + '" and temp_date BETWEEN "' + str(date1) + '" and "' + str(date2) + '" ')
            result41 = cur.fetchall()
        cur.close()
        plt.style.use('fivethirtyeight')
        x_vals=[]
        # else:
        # return redirect(url_for('checkt'))
    return render_template('graph.html', res1=result1, res2=result2, res3=result3, res4=result4, res11=result11, res21=result21, res31=result31, res41=result41)


if __name__ == '__main__':
    app.run(debug=True)